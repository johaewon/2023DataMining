#ifndef OPENPOSE_TRACKING_HEADERS_HPP
#define OPENPOSE_TRACKING_HEADERS_HPP

// tracking module
#include <openpose/tracking/personIdExtractor.hpp>
#include <openpose/tracking/personTracker.hpp>
#include <openpose/tracking/wPersonIdExtractor.hpp>

#endif // OPENPOSE_TRACKING_HEADERS_HPP
