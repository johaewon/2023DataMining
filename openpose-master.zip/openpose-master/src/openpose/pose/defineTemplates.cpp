#include <openpose/pose/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WPoseExtractor);
    DEFINE_TEMPLATE_DATUM(WPoseExtractorNet);
    DEFINE_TEMPLATE_DATUM(WPoseRenderer);
}
