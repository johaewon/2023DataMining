#include <openpose/producer/headers.hpp>

namespace op
{
    template class OP_API DatumProducer<BASE_DATUM>;
    template class OP_API WDatumProducer<BASE_DATUM>;
}
